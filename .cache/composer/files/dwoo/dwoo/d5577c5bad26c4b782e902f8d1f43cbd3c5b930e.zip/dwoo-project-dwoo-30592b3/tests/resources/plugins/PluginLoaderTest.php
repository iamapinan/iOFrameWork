<?php

function PluginLoaderTest(Dwoo\Core $dwoo)
{
    return 'Moo';
}